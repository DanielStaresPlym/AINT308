#ifndef VERGENCE_H
#define VERGENCE_H

#define IPD 0.065

double distance_calc(double Rangle, double Langle);
void angle_calc(double Lx, double Rx, double& Langle, double& Rangle);

#endif // VERGENCE_H
