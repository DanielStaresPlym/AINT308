/*
Phil Culverhouse Oct 2016 (c) Plymouth University
James Rogers Jan 2020     (c) Plymouth University

This demo code will move eye and neck servos with kepresses.
When 'c' is pressed, one eye will track the target currently within the target window.

Use this code as a base for your assignment.

*/

#include <iostream>
#include <fstream>
#include <string>
#include <sys/types.h>
#ifndef _WIN32
#include <unistd.h>
#endif
#include "owl-pwm.h"
#include "vergence.h"
#include <chrono>

#define TEST_DATA_LEN 10
#define LINEAR_CORRECTION 0.71942446
#define CONST_CORRECTION 1.5

using namespace std;

void write_result_to_file(string filename, int distances[], int len);

struct test_data {
    int distance;
    int rx;
    int lx;
};

static test_data testDataTable[] = {
    {10,    1302,	1581},
    {20,    1367,	1523},
    {30,    1392,	1491},
    {40,    1406,	1469},
    {50,    1426,	1469},
    {60,    1422,	1458},
    {70,    1431,	1459},
    {80,    1431,	1453},
    {90,    1437,	1451},
    {100,   1438,	1451}
};

int main(int argc, char *argv[]) {
    int distanceResults[TEST_DATA_LEN];

    cout << endl;
    cout << "Test 1 - no correction" << endl;
    for (int i = 0; i < TEST_DATA_LEN; i++) {
        Lx = testDataTable[i].lx;
        Rx = testDataTable[i].rx;
        //output distance
        double angleL, angleR;
        angle_calc(Lx, Rx, angleL, angleR);
        int distance = static_cast<int>(distance_calc(angleL, angleR) * 100);
        distanceResults[i] = distance;

        cout << "Left Pos, Right Pos = " << Lx << ", " << Rx << endl;
        cout << "Left Angle, Right Angle = " << angleL*180/PI << ", " << angleR*180/PI << endl;
        cout << "Estimated Distance = " << distance << "cm " << endl;
        cout << "Actual Distance = " << testDataTable[i].distance << "cm" << endl;
        cout << "Distance Difference = " << (testDataTable[i].distance - distance) << endl;
    }
    write_result_to_file("test_1_result.csv", distanceResults, TEST_DATA_LEN);

    return 0;

    cout << endl;
    cout << "Test 2 - linear correction term" << endl;
    for (int i = 0; i < TEST_DATA_LEN; i++) {
        Lx = testDataTable[i].lx;
        Rx = testDataTable[i].rx;
        //output distance
        double angleL, angleR;
        angle_calc(Lx, Rx, angleL, angleR);
        int distance = static_cast<int>(distance_calc(angleL, angleR) * 100.0 * LINEAR_CORRECTION);
        distanceResults[i] = distance;

        cout << "Left Pos, Right Pos = " << Lx << ", " << Rx << endl;
        cout << "Left Angle, Right Angle = " << angleL*180/PI << ", " << angleR*180/PI << endl;
        cout << "Estimated Distance = " << distance << "cm " << endl;
        cout << "Actual Distance = " << testDataTable[i].distance << "cm" << endl;
        cout << "Distance Difference = " << (testDataTable[i].distance - distance) << endl;
    }
    write_result_to_file("test_2_result.csv", distanceResults, TEST_DATA_LEN);

    cout << endl;
    cout << "Test 3 - constant correction term" << endl;
    for (int i = 0; i < TEST_DATA_LEN; i++) {
        Lx = testDataTable[i].lx;
        Rx = testDataTable[i].rx;
        //output distance
        double angleL, angleR;
        angle_calc(Lx, Rx, angleL, angleR);
        int distance = static_cast<int>(distance_calc(angleL, angleR) * 100.0 * LINEAR_CORRECTION + CONST_CORRECTION);
        distanceResults[i] = distance;

        cout << "Left Pos, Right Pos = " << Lx << ", " << Rx << endl;
        cout << "Left Angle, Right Angle = " << angleL*180/PI << ", " << angleR*180/PI << endl;
        cout << "Estimated Distance = " << distance << "cm " << endl;
        cout << "Actual Distance = " << testDataTable[i].distance << "cm" << endl;
        cout << "Distance Difference = " << (testDataTable[i].distance - distance) << endl;
    }
    write_result_to_file("test_3_result.csv", distanceResults, TEST_DATA_LEN);
}

void write_result_to_file(string filename, int distances[], int len) {
    fstream outputFile;
    outputFile.open(filename, ios::out);
    for (int i = 0; i < len; i++) {
        outputFile << distances[i] << endl;
    }
    outputFile.close();
}
