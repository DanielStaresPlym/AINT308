#include "owl-pwm.h"
#include "vergence.h"
#include <math.h>

void angle_calc(double Lx, double Rx, double& Langle, double& Rangle)
{
    Langle = -(LxAng * (LxC - Lx));
    Rangle = (RxAng * (RxC - Rx));
}

double distance_calc(double Langle, double Rangle){

    double dl = 0.0;
    double dc = 0.0;

    dl = (IPD * cos(Rangle) / sin(Langle + Rangle));

    dc = sqrt(dl * dl + ((IPD * IPD) / 4) - dl * IPD * sin(Langle));

    return dc;

}
